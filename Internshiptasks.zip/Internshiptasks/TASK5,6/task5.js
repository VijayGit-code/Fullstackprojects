
var express = require('express');
var app = express();
var cors = require('cors');
var mongoose = require('mongoose');
const bodyParser = require('body-parser');

app.use(cors());
app.use(bodyParser.json());

app.listen(2000, () => {
    console.log("Server running at http://localhost:2000");
});

let connect = mongoose.connect('mongodb://127.0.0.1:27017/userdata');

let schema = new mongoose.Schema({
    Registernumber: Number,
    name: String,
    branch: String,
    College: String
}, { versionKey: false });

let modelcont = mongoose.model('userdata', schema, 'studentdata');

// POST route to insert data
app.post('/data/display', async (req, res) => {
    try {
        let data = req.body;
        let m = new modelcont(data);
        await m.save();
        res.json({ message: "Inserted successfully", data: m });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET route to fetch all data
app.get('/data/display', async (req, res) => {
    try {
        const data = await modelcont.find();
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PATCH route to update data by ID
app.patch('/data/display/:id', async (req, res) => {
    try {
        let id = req.params.id;
        const mid = await modelcont.findById(id);
        if (!mid) {
            return res.status(404).json({ message: "No data found with the given ID" });
        }
        await modelcont.findByIdAndUpdate(id, { $set: req.body });
        res.json({ message: "Updated successfully" });
    } catch (err) {
        res.status(500).json({ error: "Server issue" });
    }
});

// DELETE route to delete data by ID
app.delete('/data/display/:id', async (req, res) => {
    try {
        let id = req.params.id;
        const me = await modelcont.findById(id);
        if (!me) {
            return res.status(404).json({ message: "No data found with the given ID" });
        }
        await modelcont.findByIdAndDelete(id);
        res.json({ message: "Deleted successfully" });
    } catch (err) {
        res.status(500).json({ error: "Server issue" });
    }
});
//CRUD operators post,get,patch,delete server run
