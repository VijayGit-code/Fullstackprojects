var express = require("express");
var mongoose = require("mongoose");
var path = require("path");
var bcrypt = require("bcrypt");
var pug = require('pug');

var app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
app.get("/form", (req, res) => {
  res.sendFile(__dirname + "/public/form.html");
});
app.get("/login", (req, res) => {
  res.sendFile(__dirname + "/public/login.html");
});

let conneect = mongoose
  .connect("mongodb://127.0.0.1:27017/server")
  .then(() => console.log("Mongoose connected"))
  .catch((err) => console.log(err));

let schemaa = new mongoose.Schema(
  {
    name: { type: String, required: true },
    gender: { type: String, required: true },
    mobile: { type: Number, required: true},
    email: { type: String, required: true},
    password: String,
  },
  { versionKey: false }
);

let modelconn = mongoose.model("authen", schemaa);

app.post("/user", async (req, res) => {
  try {
    const hashpassword = await bcrypt.hash(req.body.password, 10);
    var data = {
      name: req.body.name,
      gender: req.body.gender,
      mobile: req.body.mobile,
      email: req.body.email,
      password: hashpassword,
    };

    const b = new modelconn(data);
    await b.save();
    res.send("Registered Successfully");
  } catch (err) {
    res.status(500).send("Server error: " + err.message);
  }
});
app.post("/logindata", async (req, res) => {
      try {
        const user = await modelconn.findOne({ email: req.body.email });
    
        if (!user) {
          return res.status(400).json({ err: "Invalid email" });
        }
        let pass=req.body.password;
        const isPasswordValid = await bcrypt.compare( pass, user.password);
        if (!isPasswordValid) {
          return res.status(400).json({ err: "Invalid password" });
        }
    
        // res.send("Welcome " + user.name);
        res.render("sample.pug",{user});
         
      } catch (err) {
        res.status(500).send("Server issue: " + err.message);
      }
    });

    //for securing password we use bcrypt module in that use hash methode with 10 rounds